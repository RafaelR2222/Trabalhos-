class ContatoController {
    
    contatoView(req, res) {
        res.render('contato/contato');
    }
}

module.exports = ContatoController;