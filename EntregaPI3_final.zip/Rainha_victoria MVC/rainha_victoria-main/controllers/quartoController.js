class QuartoController {
    
    quartoView(req, res) {
        res.render('quarto/quarto');
    }
}

module.exports = QuartoController;