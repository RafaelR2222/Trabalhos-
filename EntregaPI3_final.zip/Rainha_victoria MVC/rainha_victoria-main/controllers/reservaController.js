class ReservaController {
    
    reservaView(req, res) {
        res.render('reserva/reserva');
    }
}

module.exports = ReservaController;